# DhakaFlix TV

Android TV / Google TV build of DhakaFlix: browse your ISP's media folders with the remote,
resume where you stopped, play in the app or in VLC. Publisher credit: MAiB_GOAT.

- Package ID: `com.maibgoat.dhakaflix.tv` (installs next to the phone app, never replaces it)
- Android 7.0 (API 24) or newer

## Media sources
Edit `CATEGORIES` in `app/src/main/java/com/maibgoat/dhakaflix/tv/Data.kt`, then rebuild.

## Build (GitHub Actions)
Workflow "Build TV release" (`.github/workflows/build-tv.yml`) unzips `DhakaFlix-TV-Source.zip`,
signs the APK with the repository secrets (SIGNING_KEY_BASE64, SIGNING_STORE_PASSWORD,
SIGNING_KEY_ALIAS, SIGNING_KEY_PASSWORD) and publishes a release tagged `tv-v<versionName>`.
To ship an update: raise `versionCode` and `versionName` in `app/build.gradle.kts`, re-zip, upload, run the workflow.
