package com.maibgoat.dhakaflix.tv

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.os.Process
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

// =====================================================================
//  1. EDIT THIS LIST: your ISP's folders.
//     Open each URL in a browser on your ISP's Wi-Fi first. If it shows a
//     folder listing, it works. Copy the address EXACTLY as the browser shows it.
//     series = true  ->  every title in that category is a TV show with seasons.
// =====================================================================
class Category(val name: String, val url: String, val series: Boolean = false)

val CATEGORIES = listOf(
    Category("English", "http://172.16.50.7/DHAKA-FLIX-7/English%20Movies/"),
    Category("Hindi", "http://172.16.50.14/DHAKA-FLIX-14/Hindi%20Movies/"),
    Category("TV & Web Series", "http://172.16.50.12/DHAKA-FLIX-12/TV-WEB-Series/", series = true),
    // Category("Anime", "http://172.16.50.9/DHAKA-FLIX-9/Anime/", series = true),
)

// Max simultaneous requests to the (shared) ISP server. Lower these if the server gets slow.
private const val SCAN_PARALLEL = 3
private const val UI_PARALLEL = 3

const val SEC_CONTINUE = "Continue"
const val SEC_SEARCH = "Search"

// ---------------------------------------------------------------------
//  Models
// ---------------------------------------------------------------------
class Title(
    val href: String,          // full URL of the title's folder (also its unique id)
    val category: String,
    val name: String,
    val year: Int,
    val quality: String,
    val dual: Boolean,
    val added: Long,
    val kind: Int,             // 0 = movie, 1 = series
    val poster: String?,
    val video: String?,
    val resolved: Boolean,
) {
    val isSeries: Boolean get() = kind == 1
}

class Entry(val url: String, val name: String, val dir: Boolean, val time: Long, val size: Long)
class Parsed(val title: String, val year: Int, val quality: String, val dual: Boolean, val series: Boolean)
class Season(val url: String, val name: String)
class Episode(val url: String, val file: String, val label: String, val season: Int, val num: Int)
class Prog(val position: Long, val duration: Long, val watched: Boolean)

// ---------------------------------------------------------------------
//  Folder-name parsing: "a folder whose name ends in a single year in brackets is a title;
//  anything else is a group to walk into."
// ---------------------------------------------------------------------
private val MOVIE_RE = Regex("""^(?:\d{3}\.\s+)?([^(].*?)\s*\((\d{4})\)(.*)$""")
private val SHOW_RE = Regex("""^(?:\d{3}\.\s+)?([^(].*?)\s*\((?:TV|Web)[^)]*?(\d{4})[^)]*\)(.*)$""", RegexOption.IGNORE_CASE)
private val EVENT_RE = Regex("""^([^(].*?)\s*\(\d{2}-\d{2}-(\d{4})\)(.*)$""")
private val QUALITY_RE = Regex("""(2160|1080|720|480)p""", RegexOption.IGNORE_CASE)
private val DUAL_RE = Regex("""dual|multi""", RegexOption.IGNORE_CASE)

fun parseTitle(name: String): Parsed? {
    val tries = listOf(SHOW_RE to true, MOVIE_RE to false, EVENT_RE to false)
    for ((re, series) in tries) {
        val m = re.find(name) ?: continue
        val rest = m.groupValues[3]
        return Parsed(
            title = m.groupValues[1].trim(),
            year = m.groupValues[2].toInt(),
            quality = QUALITY_RE.find(rest)?.value?.lowercase() ?: "",
            dual = DUAL_RE.containsMatchIn(rest),
            series = series,
        )
    }
    return null
}

// ---------------------------------------------------------------------
//  Folder listing parser (works for h5ai, nginx autoindex and Apache autoindex)
// ---------------------------------------------------------------------
private val HREF_RE = Regex("""href\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE)
private val DATE_ISO = Regex("""(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2})""")
private val DATE_NGX = Regex("""(\d{2})-([A-Za-z]{3})-(\d{4})\s+(\d{2}):(\d{2})""")
private val SIZE_RE = Regex("""fb-s"[^>]*>\s*(\d[\d,]*)\s*<""")

fun dec(s: String): String =
    try { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") } catch (e: Exception) { s }

fun parseListing(pageUrl: String, html: String): List<Entry> {
    val u = URL(pageUrl)
    val origin = u.protocol + "://" + u.authority
    val basePath = if (u.path.endsWith("/")) u.path else u.path + "/"
    val baseDec = dec(basePath)
    val f1 = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
    val f2 = SimpleDateFormat("dd-MMM-yyyy HH:mm", Locale.US)
    val out = LinkedHashMap<String, Entry>()
    val n = html.length
    var pos = 0

    // IMPORTANT: never run a regex over the whole page. On Android every regex search over a multi-megabyte
    // string copies that string, thousands of times per page, which can freeze a small TV. Plain text search
    // (indexOf) finds each link tag; regexes only ever see tiny pieces.
    while (pos < n) {
        val a = html.indexOf("<a ", pos)
        if (a < 0) break
        val gt = html.indexOf('>', a)
        if (gt < 0) break
        pos = gt + 1                                  // advance first, so 'continue' below is safe
        val hm = HREF_RE.find(html.substring(a, gt)) ?: continue
        val href = hm.groupValues[1].trim().replace("&amp;", "&")
        if (href.isEmpty() || href[0] == '?' || href[0] == '#' || '?' in href) continue
        if (href.startsWith("javascript", true) || href.startsWith("mailto", true)) continue

        val path: String = when {
            href.startsWith("http", true) -> try { URL(href).path } catch (e: Exception) { continue }
            href.startsWith("/") -> href
            else -> basePath + href.removePrefix("./")
        }
        val pd = dec(path)
        if (!pd.startsWith(baseDec)) continue                 // parent folder, breadcrumbs, other sites
        val rest = pd.substring(baseDec.length).trimEnd('/')
        if (rest.isEmpty() || '/' in rest) continue           // the folder itself, or deeper levels
        val existing = out[pd]
        if (existing != null && existing.time != 0L) continue

        // the few hundred characters after the link hold its date and size
        var chunk = html.substring(pos, minOf(pos + 500, n))
        val cut = chunk.indexOf("<a ")
        if (cut >= 0) chunk = chunk.substring(0, cut)

        var time = 0L
        val d1 = DATE_ISO.find(chunk)
        val d2 = DATE_NGX.find(chunk)
        if (d1 != null) {
            val g = d1.groupValues
            time = try { f1.parse("${g[1]}-${g[2]}-${g[3]} ${g[4]}:${g[5]}")!!.time } catch (e: Exception) { 0L }
        } else if (d2 != null) {
            val g = d2.groupValues
            time = try { f2.parse("${g[1]}-${g[2]}-${g[3]} ${g[4]}:${g[5]}")!!.time } catch (e: Exception) { 0L }
        }
        val kb = SIZE_RE.find(chunk)?.groupValues?.get(1)?.replace(",", "")?.toLongOrNull() ?: 0L

        out[pd] = Entry(
            url = origin + Uri.encode(path, "/%()[]!\$&'*+,;=:@"),
            name = dec(rest),
            dir = href.endsWith("/"),
            time = time,
            size = kb * 1024,
        )
    }
    return out.values.toList()
}

// ---------------------------------------------------------------------
//  Small helpers
// ---------------------------------------------------------------------
object Http {
    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 25000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) DhakaFlix")
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            val sb = StringBuilder(64 * 1024)
            c.inputStream.bufferedReader().use { r ->
                val buf = CharArray(16 * 1024)
                while (true) {
                    val n = r.read(buf)
                    if (n < 0) break
                    sb.append(buf, 0, n)
                    if (sb.length > 6_000_000) throw IOException("page too large")
                }
            }
            return sb.toString()
        } finally {
            c.disconnect()
        }
    }
}

private val IMG = setOf("jpg", "jpeg", "png", "webp")
private val VID = setOf("mkv", "mp4", "avi", "m4v", "webm", "mov", "ts", "wmv", "flv", "mpg", "mpeg")
private fun ext(n: String) = n.substringAfterLast('.', "").lowercase()

private val TOKENS = Regex("""\d+|\D+""")
fun natCompare(a: String, b: String): Int {
    val x = TOKENS.findAll(a.lowercase()).map { it.value }.toList()
    val y = TOKENS.findAll(b.lowercase()).map { it.value }.toList()
    for (i in 0 until minOf(x.size, y.size)) {
        val p = x[i]
        val q = y[i]
        val c = if (p[0].isDigit() && q[0].isDigit()) {
            val pn = p.trimStart('0').ifEmpty { "0" }
            val qn = q.trimStart('0').ifEmpty { "0" }
            if (pn.length != qn.length) pn.length - qn.length else pn.compareTo(qn)
        } else p.compareTo(q)
        if (c != 0) return c
    }
    return x.size - y.size
}

private val EP_RE = Regex("""S(\d{1,2})\s*E(\d{1,3})""", RegexOption.IGNORE_CASE)
private fun makeEpisode(e: Entry): Episode {
    val m = EP_RE.find(e.name)
    return if (m != null) {
        val s = m.groupValues[1].toInt()
        val n = m.groupValues[2].toInt()
        Episode(e.url, e.name, String.format(Locale.US, "S%02dE%02d", s, n), s, n)
    } else Episode(e.url, e.name, "•", 0, 0)
}

// ---------------------------------------------------------------------
//  Database
// ---------------------------------------------------------------------
class Db(ctx: Context) : SQLiteOpenHelper(ctx, "dhakaflix.db", null, 1) {
    init { setWriteAheadLoggingEnabled(true) }   // background scan must not block the screen's reads

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE movies(href TEXT PRIMARY KEY, parent TEXT, category TEXT, title TEXT, year INT, " +
                "quality TEXT, dual INT, added INT, kind INT, seen INT, poster TEXT, video TEXT, resolved INT DEFAULT 0)"
        )
        db.execSQL("CREATE INDEX movies_cat_added ON movies(category, added)")
        db.execSQL("CREATE INDEX movies_parent ON movies(parent)")
        db.execSQL("CREATE TABLE dirs(href TEXT PRIMARY KEY, time INT)")
        db.execSQL("CREATE TABLE progress(url TEXT PRIMARY KEY, parent TEXT, position INT, duration INT, watched INT, updated INT)")
        db.execSQL("CREATE TABLE meta(href TEXT PRIMARY KEY, json TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
}

// ---------------------------------------------------------------------
//  Repository: crawler + queries
// ---------------------------------------------------------------------
object Repo {
    private lateinit var db: SQLiteDatabase
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    // The crawler runs on 2 low-priority threads so it never starves the screen or the system.
    private val scanDisp = Executors.newFixedThreadPool(2) { r ->
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            r.run()
        }
    }.asCoroutineDispatcher()
    private val scanScope = CoroutineScope(SupervisorJob() + scanDisp)
    private var scanSem = Semaphore(SCAN_PARALLEL)
    private var uiSem = Semaphore(UI_PARALLEL)
    private var lite = false                    // weak TV: slower, gentler crawling
    private var lastTick = 0L
    @Volatile var step: String = "idle"            // what the scanner is doing (shown on the TV)
    @Volatile var lastError: String = ""
    private val pages = AtomicInteger(0)
    private val titlesSeen = AtomicInteger(0)
    private val failed = AtomicInteger(0)

    val scanning = MutableStateFlow(false)
    val status = MutableStateFlow("")
    val tick = MutableStateFlow(0)          // bumps whenever new titles may be available

    private const val COLS = "href,category,title,year,quality,dual,added,kind,poster,video,resolved"
    private const val MCOLS = "m.href,m.category,m.title,m.year,m.quality,m.dual,m.added,m.kind,m.poster,m.video,m.resolved"

    fun init(ctx: Context, lite: Boolean = false) {
        this.lite = lite
        if (lite) {
            scanSem = Semaphore(1)
            uiSem = Semaphore(2)
        }
        if (!::db.isInitialized) db = Db(ctx.applicationContext).writableDatabase
    }

    /** Tell the screen "new titles may exist", but at most every 2 seconds (unless forced). */
    private fun bump(force: Boolean = false) {
        val n = System.currentTimeMillis()
        if (force || n - lastTick > 2000) {
            lastTick = n
            tick.update { it + 1 }
        }
    }

    private suspend fun <T> safe(block: suspend () -> T): T? =
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.message}".take(90)
            null
        }

    private suspend fun list(
        url: String,
        sem: Semaphore,
        disp: CoroutineDispatcher = Dispatchers.IO,
        paceMs: Long = 0L,
    ): List<Entry>? = safe {
        sem.withPermit {
            val r = withContext(disp) { parseListing(url, Http.get(url)) }
            if (paceMs > 0L) delay(paceMs)
            r
        }
    }

    // ----- reading titles -----
    private fun rows(c: Cursor): List<Title> {
        val out = ArrayList<Title>()
        c.use {
            while (it.moveToNext()) {
                out.add(
                    Title(
                        href = it.getString(0),
                        category = it.getString(1) ?: "",
                        name = it.getString(2) ?: "",
                        year = it.getInt(3),
                        quality = it.getString(4) ?: "",
                        dual = it.getInt(5) == 1,
                        added = it.getLong(6),
                        kind = it.getInt(7),
                        poster = it.getString(8)?.takeIf { s -> s.isNotBlank() },
                        video = it.getString(9)?.takeIf { s -> s.isNotBlank() },
                        resolved = it.getInt(10) == 1,
                    )
                )
            }
        }
        return out
    }

    /** sort: 0 = latest added, 1 = A-Z, 2 = year */
    suspend fun query(section: String, q: String, sort: Int, limit: Int): List<Title> = withContext(Dispatchers.IO) {
        val order = when (sort) {
            1 -> "title COLLATE NOCASE ASC"
            2 -> "year DESC, title COLLATE NOCASE ASC"
            else -> "added DESC"
        }
        when (section) {
            SEC_CONTINUE -> rows(
                db.rawQuery(
                    "SELECT $MCOLS FROM movies m JOIN (SELECT parent, MAX(updated) u FROM progress " +
                        "WHERE watched=0 AND position>10000 GROUP BY parent) p ON p.parent=m.href " +
                        "ORDER BY p.u DESC LIMIT $limit", null
                )
            )
            SEC_SEARCH ->
                if (q.isBlank()) emptyList()
                else rows(db.rawQuery("SELECT $COLS FROM movies WHERE title LIKE ? ORDER BY $order LIMIT $limit", arrayOf("%${q.trim()}%")))
            else -> rows(db.rawQuery("SELECT $COLS FROM movies WHERE category=? ORDER BY $order LIMIT $limit", arrayOf(section)))
        }
    }

    private fun getTitle(href: String): Title? =
        rows(db.rawQuery("SELECT $COLS FROM movies WHERE href=?", arrayOf(href))).firstOrNull()

    // ----- lazily open a title folder: find its poster and its video file -----
    private fun pickVideo(files: List<Entry>): String? {
        val vids = files.filter { ext(it.name) in VID }
        val noSample = vids.filter { !it.name.contains("sample", ignoreCase = true) }
        return (if (noSample.isNotEmpty()) noSample else vids).maxByOrNull { it.size }?.url
    }

    suspend fun resolve(href: String): Title? = withContext(Dispatchers.IO) {
        val t = getTitle(href) ?: return@withContext null
        if (t.resolved) return@withContext t
        val es = list(href, uiSem) ?: return@withContext t        // network problem: try again later
        val files = es.filter { !it.dir }
        val imgs = files.filter { ext(it.name) in IMG }
        val poster = (imgs.firstOrNull { "_AL_" in it.name } ?: imgs.firstOrNull())?.url
        var video = pickVideo(files)
        if (video == null && t.kind == 0) {                        // some movies keep the file one folder deeper
            for (d in es.filter { it.dir }.take(3)) {
                val sub = list(d.url, uiSem) ?: continue
                video = pickVideo(sub.filter { !it.dir })
                if (video != null) break
            }
        }
        val cv = ContentValues().apply {
            put("poster", poster ?: "")
            put("video", video ?: "")
            put("resolved", 1)
        }
        db.update("movies", cv, "href=?", arrayOf(href))
        getTitle(href)
    }

    // ----- TV shows -----
    suspend fun seasons(showUrl: String): List<Season> {
        val es = list(showUrl, uiSem) ?: return emptyList()
        val out = es.filter { it.dir }
            .sortedWith(Comparator { a, b -> natCompare(a.name, b.name) })
            .map { Season(it.url, it.name) }
            .toMutableList()
        if (es.any { !it.dir && ext(it.name) in VID }) out.add(0, Season(showUrl, "Episodes"))
        return out
    }

    suspend fun episodes(seasonUrl: String): List<Episode> {
        val es = list(seasonUrl, uiSem) ?: return emptyList()
        return es.filter { !it.dir && ext(it.name) in VID }
            .sortedWith(Comparator { a, b -> natCompare(a.name, b.name) })
            .map { makeEpisode(it) }
    }

    // ----- watch progress -----
    suspend fun progressOf(urls: List<String>): Map<String, Prog> = withContext(Dispatchers.IO) {
        val out = HashMap<String, Prog>()
        for (chunk in urls.chunked(400)) {
            val marks = chunk.joinToString(",") { "?" }
            db.rawQuery("SELECT url,position,duration,watched FROM progress WHERE url IN ($marks)", chunk.toTypedArray()).use {
                while (it.moveToNext()) out[it.getString(0)] = Prog(it.getLong(1), it.getLong(2), it.getInt(3) == 1)
            }
        }
        out
    }

    suspend fun lastEpisodeUrl(parent: String): String? = withContext(Dispatchers.IO) {
        db.rawQuery("SELECT url FROM progress WHERE parent=? ORDER BY updated DESC LIMIT 1", arrayOf(parent)).use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }

    fun saveProgress(url: String, parent: String, pos: Long, dur: Long, watched: Boolean, onDone: (() -> Unit)? = null) {
        scope.launch {
            val cv = ContentValues().apply {
                put("url", url)
                put("parent", parent)
                put("position", pos)
                put("duration", dur)
                put("watched", if (watched) 1 else 0)
                put("updated", System.currentTimeMillis())
            }
            db.insertWithOnConflict("progress", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            if (onDone != null) withContext(Dispatchers.Main) { onDone() }
        }
    }

    fun markWatched(url: String, parent: String) = saveProgress(url, parent, 0, 1, true)

    // ----- Cinemeta cache -----
    fun cachedMeta(href: String): String? =
        db.rawQuery("SELECT json FROM meta WHERE href=?", arrayOf(href)).use { if (it.moveToFirst()) it.getString(0) else null }

    fun putMeta(href: String, json: String) {
        val cv = ContentValues().apply { put("href", href); put("json", json) }
        db.insertWithOnConflict("meta", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    // ----- the crawler -----
    /** full = forget which folders were seen and re-list everything (slow, but fixes missed changes). */
    fun scan(full: Boolean = false) {
        if (scanning.value) return
        scanning.value = true
        failed.set(0)
        pages.set(0)
        titlesSeen.set(0)
        scanScope.launch {
            try {
                if (lite) delay(3000)               // let the screen settle first
                if (full) {
                    db.execSQL("DELETE FROM dirs")
                    db.execSQL("UPDATE movies SET resolved=0 WHERE poster IS NULL OR poster=''")
                }
                val stamp = System.currentTimeMillis()
                for (cat in CATEGORIES) {
                    status.value = "Scanning ${cat.name}…"
                    walk(cat, cat.url, 0, stamp)
                    bump(true)
                }
                val f = failed.get()
                status.value = if (f > 0) "Couldn't reach the server for $f folder(s). Are you on your ISP's network?" else ""
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                lastError = "${e.javaClass.simpleName}: ${e.message}".take(90)
                status.value = "Scan problem: ${e.message}"
            } finally {
                step = "idle (scan finished)"
                scanning.value = false
                bump(true)
            }
        }
    }

    private fun dirTime(url: String): Long =
        db.rawQuery("SELECT time FROM dirs WHERE href=?", arrayOf(url)).use { if (it.moveToFirst()) it.getLong(0) else -1L }

    private fun setDirTime(url: String, t: Long) {
        db.execSQL("INSERT OR REPLACE INTO dirs(href,time) VALUES(?,?)", arrayOf<Any>(url, t))
    }

    private fun upsert(e: Entry, p: Parsed, cat: Category, parent: String, stamp: Long) {
        titlesSeen.incrementAndGet()
        val cv = ContentValues().apply {
            put("href", e.url)
            put("parent", parent)
            put("category", cat.name)
            put("title", p.title)
            put("year", p.year)
            put("quality", p.quality)
            put("dual", if (p.dual) 1 else 0)
            put("added", e.time)
            put("kind", if (cat.series || p.series) 1 else 0)
            put("seen", stamp)
        }
        if (db.update("movies", cv, "href=?", arrayOf(e.url)) == 0) db.insertOrThrow("movies", null, cv)
    }

    /** Lists one group folder. Title folders are stored without being opened. Changed sub-groups are walked. */
    private suspend fun walk(cat: Category, url: String, depth: Int, stamp: Long) {
        step = "fetching …${url.takeLast(45)}"
        val es = list(url, scanSem, scanDisp, if (lite) 150L else 0L)
        if (es == null) {
            failed.incrementAndGet()
            return
        }
        pages.incrementAndGet()
        step = "storing ${es.size} entries from …${url.takeLast(45)} (${pages.get()} pages, ${titlesSeen.get()} titles)"
        val groups = ArrayList<Entry>()
        db.beginTransaction()
        try {
            for (e in es) {
                if (!e.dir) continue
                val p = parseTitle(e.name)
                if (p != null) upsert(e, p, cat, url, stamp)
                else if (depth < 6 && (e.time == 0L || dirTime(e.url) != e.time)) groups.add(e)
            }
            // mark & sweep: titles that used to be in this folder but weren't seen now were deleted by the ISP
            db.execSQL("DELETE FROM movies WHERE parent=? AND seen<>?", arrayOf<Any>(url, stamp))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        coroutineScope {
            for (g in groups) {
                launch {
                    walk(cat, g.url, depth + 1, stamp)
                    setDirTime(g.url, g.time)
                }
            }
        }
        if (depth <= 1) bump()
    }
}
