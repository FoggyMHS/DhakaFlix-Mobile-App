package com.maibgoat.dhakaflix.tv

import android.app.ActivityManager
import android.content.Context
import android.os.Build

/** One-line health report: Android version, memory, and what the scanner is doing right now. */
object Diag {
    fun snapshot(ctx: Context): String {
        val rt = Runtime.getRuntime()
        val usedMb = (rt.totalMemory() - rt.freeMemory()) / 1048576
        val maxMb = rt.maxMemory() / 1048576
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val freeMb = mi.availMem / 1048576
        val low = if (mi.lowMemory) " LOW-MEMORY" else ""
        val err = if (Repo.lastError.isNotEmpty()) " | last error: ${Repo.lastError}" else ""
        return "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) | app memory ${usedMb}/${maxMb} MB | " +
            "free RAM ${freeMb} MB$low | ${Repo.step}$err"
    }
}
