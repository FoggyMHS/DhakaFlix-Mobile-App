package com.maibgoat.dhakaflix.tv

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URLEncoder
import kotlin.math.abs

class Meta(
    val rating: String?,
    val plot: String?,
    val genres: List<String>,
    val runtime: String?,
    val cast: List<String>,
    val director: String?,
    val background: String?,
    val episodeNames: Map<String, String>,   // "season x episode" -> episode name, e.g. "1x5"
)

/** Free IMDb-based metadata from Stremio's Cinemeta. No API key. Needs internet (not just the ISP network). */
object Cinemeta {
    private const val BASE = "https://v3-cinemeta.strem.io"
    private val YEAR = Regex("""\d{4}""")

    private fun clean(n: String): String =
        n.replace(Regex("""^\d{1,3}\s+-\s+"""), "")
            .replace(Regex("""[-_:]+"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()

    suspend fun load(t: Title): Meta? = withContext(Dispatchers.IO) {
        val cached = Repo.cachedMeta(t.href)
        if (cached != null) return@withContext parse(cached)
        val type = if (t.isSeries) "series" else "movie"
        try {
            val q = URLEncoder.encode(clean(t.name), "UTF-8").replace("+", "%20")
            val hits = JSONObject(Http.get("$BASE/catalog/$type/top/search=$q.json")).optJSONArray("metas")
            var id = ""
            if (hits != null) {
                for (i in 0 until hits.length()) {
                    val o = hits.optJSONObject(i) ?: continue
                    val y = YEAR.find(o.optString("releaseInfo", o.optString("year", "")))?.value?.toIntOrNull()
                    if (t.year == 0 || y == null || abs(y - t.year) <= 1) {
                        id = o.optString("id", "")
                        break
                    }
                }
            }
            if (id.isEmpty()) {
                Repo.putMeta(t.href, "{}")                      // remember "not found" so we don't ask again
                null
            } else {
                val json = Http.get("$BASE/meta/$type/$id.json") // redirects (307) are followed automatically
                Repo.putMeta(t.href, json)
                parse(json)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null                                                // offline or error: try again next time
        }
    }

    private fun parse(json: String): Meta? {
        val m = JSONObject(json).optJSONObject("meta") ?: return null
        fun arr(k: String): List<String> {
            val a = m.optJSONArray(k) ?: return emptyList()
            return (0 until a.length()).map { a.optString(it) }
        }
        val eps = HashMap<String, String>()
        val vids = m.optJSONArray("videos")
        if (vids != null) {
            for (i in 0 until vids.length()) {
                val o = vids.optJSONObject(i) ?: continue
                val n = o.optString("name", o.optString("title", ""))
                if (n.isNotBlank()) eps["${o.optInt("season")}x${o.optInt("episode")}"] = n
            }
        }
        return Meta(
            rating = m.optString("imdbRating", "").ifBlank { null },
            plot = m.optString("description", "").ifBlank { null },
            genres = arr("genres"),
            runtime = m.optString("runtime", "").ifBlank { null },
            cast = arr("cast"),
            director = arr("director").joinToString(", ").ifBlank { null },
            background = m.optString("background", "").ifBlank { null },
            episodeNames = eps,
        )
    }
}
