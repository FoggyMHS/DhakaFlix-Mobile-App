package com.maibgoat.dhakaflix.tv

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

// =====================================================================
//  HOME: category tabs + poster grid + search
// =====================================================================
@Composable
fun HomeScreen(app: AppState) {
    val ctx = LocalContext.current
    val tv = remember { isTv(ctx) }
    val wide = LocalConfiguration.current.screenWidthDp >= 600
    val tick by Repo.tick.collectAsState()
    val scanning by Repo.scanning.collectAsState()
    val status by Repo.status.collectAsState()
    val searchFocus = remember { FocusRequester() }

    // (Re)load the list whenever the section, search text, sort, page size or scan progress changes.
    LaunchedEffect(app.section, app.query, app.sort, app.limit, tick) {
        if (app.section == SEC_SEARCH) delay(250)       // wait while the person is still typing
        app.items = Repo.query(app.section, app.query, app.sort, app.limit)
    }
    LaunchedEffect(app.section) {
        if (app.section == SEC_SEARCH && app.restoreFocus == null) runCatching { searchFocus.requestFocus() }
    }

    // Endless scrolling: when the end of the loaded list is near, ask for 300 more.
    val lastVisible by remember {
        derivedStateOf { app.gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
    }
    LaunchedEffect(lastVisible, app.items.size) {
        if (app.items.size >= app.limit && lastVisible >= app.items.size - 24) app.limit += Lite.page
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .safeDrawingPadding()
            .padding(horizontal = 14.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("DhakaFlix", color = Accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Box(Modifier.weight(1f))
            if (scanning) Text("Scanning…", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(end = 10.dp))
            ActionButton(
                when (app.playerPref) {
                    "vlc" -> "Player: VLC"
                    "app" -> "Player: In-app"
                    else -> "Player: Ask"
                }
            ) { app.cyclePlayer() }
        }

        val sections = listOf(SEC_CONTINUE) + CATEGORIES.map { it.name } + SEC_SEARCH
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 10.dp),
        ) {
            items(sections) { s -> Chip(s, app.section == s) { app.select(s) } }
            item { ActionButton("Rescan") { Repo.scan(full = true) } }
            item { ActionButton(if (app.posters) "Posters: On" else "Posters: Off") { app.togglePosters() } }
        }

        if (app.section != SEC_CONTINUE && app.section != SEC_SEARCH) {
            Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Latest", "A–Z", "Year").forEachIndexed { i, label ->
                    Chip(label, app.sort == i) { app.sort = i; app.limit = Lite.page }
                }
            }
        }

        if (app.section == SEC_SEARCH) {
            OutlinedTextField(
                value = app.query,
                onValueChange = { app.query = it; app.limit = Lite.page },
                singleLine = true,
                placeholder = { Text("Search titles") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).focusRequester(searchFocus),
            )
        }

        if (status.isNotEmpty()) Text(status, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))

        if (Lite.on) {                                  // TV: live health line, for diagnosing crashes
            var diag by remember { mutableStateOf("") }
            LaunchedEffect(Unit) {
                while (true) {
                    diag = Diag.snapshot(ctx)
                    delay(2000)
                }
            }
            Text(diag, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(bottom = 4.dp))
        }

        if (app.items.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    when {
                        app.section == SEC_CONTINUE -> "Nothing in progress yet."
                        app.section == SEC_SEARCH -> "Type a title to search."
                        scanning -> "Scanning your ISP server. Titles appear here as they are found…"
                        else -> "No titles yet. Check that you're on your ISP's Wi-Fi, then tap Rescan."
                    },
                    color = Muted,
                    modifier = Modifier.padding(24.dp),
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(if (Lite.on) 190.dp else if (wide) 150.dp else 100.dp),
                state = app.gridState,
                contentPadding = PaddingValues(bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(app.items, key = { it.href }) { t ->
                    val fr = remember { FocusRequester() }
                    LaunchedEffect(Unit) {
                        // coming Back from a title: put the TV remote focus on the same poster
                        if (tv && app.restoreFocus == t.href) {
                            runCatching { fr.requestFocus() }
                            app.restoreFocus = null
                        }
                    }
                    PosterCard(t, Modifier.focusRequester(fr), showPoster = app.posters) {
                        if (tv) app.restoreFocus = t.href
                        app.push(Screen.Detail(t))
                    }
                }
            }
        }
    }
}

// =====================================================================
//  DETAIL: poster, rating, plot, Play / Resume, VLC, and seasons for shows
// =====================================================================
@Composable
fun DetailScreen(app: AppState, t0: Title) {
    val ctx = LocalContext.current
    val tv = remember { isTv(ctx) }
    val wide = LocalConfiguration.current.screenWidthDp >= 600
    var t by remember { mutableStateOf(t0) }
    var meta by remember { mutableStateOf<Meta?>(null) }
    var prog by remember { mutableStateOf<Prog?>(null) }
    var ready by remember { mutableStateOf(false) }
    val firstFocus = remember { FocusRequester() }

    LaunchedEffect(t0.href) {
        val r = Repo.resolve(t0.href)
        if (r != null) t = r
    }
    LaunchedEffect(t0.href) { meta = Cinemeta.load(t0) }
    LaunchedEffect(t.video, t.resolved, app.progressTick) {
        val v = t.video
        if (!t.isSeries) {
            if (v != null) prog = Repo.progressOf(listOf(v))[v]
            if (v != null || t.resolved) ready = true
        }
    }
    LaunchedEffect(ready) { if (tv && ready) runCatching { firstFocus.requestFocus() } }

    val m = meta
    val resumePos: Long? = prog?.let { if (!it.watched && it.position > 10_000) it.position else null }

    fun play(fromStart: Boolean) {
        val v = t.video ?: return
        val pos = if (fromStart) 0L else (resumePos ?: 0L)
        app.play(ctx, PlayRequest(listOf(QItem(v, t.name)), 0, pos, t.href))
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        val bgUrl = if (app.posters) m?.background else null
        if (bgUrl != null) {
            AsyncImage(
                model = bgUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = 0.30f,
                modifier = Modifier.fillMaxWidth().height(280.dp),
            )
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Bg)))
            )
        }

        Column(
            Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            ActionButton("← Back") { app.back() }
            Spacer(Modifier.height(14.dp))

            Row {
                val posterUrl = if (app.posters) t.poster else null
                if (posterUrl != null) {
                    AsyncImage(
                        model = posterUrl,
                        contentDescription = t.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .width(if (wide) 180.dp else 110.dp)
                            .aspectRatio(2f / 3f)
                            .clip(RoundedCornerShape(10.dp)),
                    )
                    Spacer(Modifier.width(16.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(t.name, color = TextHi, fontSize = if (wide) 30.sp else 22.sp, fontWeight = FontWeight.Bold)
                    val info = buildList {
                        if (t.year > 0) add(t.year.toString())
                        if (t.quality.isNotEmpty()) add(t.quality)
                        if (t.dual) add("Dual audio")
                        m?.rating?.let { add("IMDb $it") }
                        m?.runtime?.let { add(it) }
                    }.joinToString("  ·  ")
                    if (info.isNotEmpty()) Text(info, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    if (m != null && m.genres.isNotEmpty()) {
                        Text(m.genres.joinToString(", "), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            if (!t.isSeries) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    val v = t.video
                    if (v != null) {
                        ActionButton(
                            if (resumePos != null) "▶ Resume ${fmtTime(resumePos)}" else "▶ Play",
                            Modifier.focusRequester(firstFocus),
                            primary = true,
                        ) { play(false) }
                        if (resumePos != null) ActionButton("Restart") { play(true) }
                        ActionButton("Open in VLC") { app.launch(ctx, "vlc", PlayRequest(listOf(QItem(v, t.name)), 0, resumePos ?: 0L, t.href)) }
                    } else if (t.resolved) {
                        Text("No video file found in this folder.", color = Muted)
                    } else {
                        Text("Loading…", color = Muted)
                    }
                }
            }

            val plot = m?.plot
            if (plot != null) Text(plot, color = TextHi, fontSize = 14.sp, modifier = Modifier.padding(top = 16.dp))
            if (m != null && m.cast.isNotEmpty()) {
                Text("Cast: " + m.cast.take(6).joinToString(", "), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
            }
            if (m?.director != null) Text("Director: ${m.director}", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))

            if (t.isSeries) SeriesSection(app, t, m, firstFocus, tv)

            if (m != null) Text("Details: Cinemeta / IMDb", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 24.dp))
        }
    }
}

// =====================================================================
//  SERIES: season chips + episode list (episodes are listed only when opened)
// =====================================================================
@Composable
fun SeriesSection(app: AppState, show: Title, meta: Meta?, firstFocus: FocusRequester, tv: Boolean) {
    val ctx = LocalContext.current
    var seasons by remember { mutableStateOf<List<Season>?>(null) }
    var sel by remember { mutableIntStateOf(app.lastSeason[show.href] ?: -1) }
    var eps by remember { mutableStateOf<List<Episode>?>(null) }
    var prog by remember { mutableStateOf<Map<String, Prog>>(emptyMap()) }

    LaunchedEffect(show.href) {
        val s = Repo.seasons(show.href)
        seasons = s
        if (sel < 0) {
            // open on the season you watched last
            val last = Repo.lastEpisodeUrl(show.href)
            sel = if (last != null) {
                s.withIndex().filter { last.startsWith(it.value.url) }.maxByOrNull { it.value.url.length }?.index ?: 0
            } else 0
        }
    }
    LaunchedEffect(seasons, sel) {
        val s = seasons?.getOrNull(sel) ?: return@LaunchedEffect
        eps = null
        val list = Repo.episodes(s.url)
        prog = Repo.progressOf(list.map { it.url })
        eps = list
    }
    LaunchedEffect(eps) {
        if (tv && eps != null) runCatching { firstFocus.requestFocus() }
    }
    LaunchedEffect(app.progressTick) {          // VLC just closed: refresh the watched / resume marks
        val l = eps
        if (l != null) prog = Repo.progressOf(l.map { it.url })
    }

    Spacer(Modifier.height(20.dp))
    val ss = seasons
    if (ss == null) {
        Text("Loading seasons…", color = Muted)
        return
    }
    if (ss.isEmpty()) {
        Text("No episodes found, or the server didn't answer.", color = Muted)
        return
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ss.forEachIndexed { i, s -> Chip(s.name, i == sel) { sel = i; app.lastSeason[show.href] = i } }
    }
    Spacer(Modifier.height(12.dp))

    val list = eps
    if (list == null) {
        Text("Loading episodes…", color = Muted)
        return
    }
    if (list.isEmpty()) {
        Text("No video files in this season.", color = Muted)
        return
    }
    val focusIdx = run {
        val partial = list.indexOfFirst { e -> prog[e.url]?.let { !it.watched && it.position > 10_000 } == true }
        if (partial >= 0) partial else list.indexOfFirst { e -> prog[e.url]?.watched != true }.coerceAtLeast(0)
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        list.forEachIndexed { i, ep ->
            val p = prog[ep.url]
            EpisodeRow(
                ep = ep,
                name = meta?.episodeNames?.get("${ep.season}x${ep.num}"),
                p = p,
                modifier = if (i == focusIdx) Modifier.focusRequester(firstFocus) else Modifier,
            ) {
                // play this episode and let the rest of the season follow automatically
                val queue = list.drop(i).map { QItem(it.url, "${show.name} ${it.label}") }
                val pos = if (p != null && !p.watched && p.position > 10_000) p.position else 0L
                app.play(ctx, PlayRequest(queue, 0, pos, show.href))
            }
        }
    }
}

@Composable
fun EpisodeRow(ep: Episode, name: String?, p: Prog?, modifier: Modifier, onClick: () -> Unit) {
    Focusable(onClick = onClick, modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp), scaleOnFocus = 1.01f) {
        Column(Modifier.background(Panel).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(ep.label, color = Accent, fontWeight = FontWeight.Bold, modifier = Modifier.width(76.dp))
                Text(
                    name ?: ep.file.substringBeforeLast('.'),
                    color = TextHi,
                    fontSize = 14.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                val tag = when {
                    p == null -> ""
                    p.watched -> "✓ watched"
                    else -> fmtTime(p.position)
                }
                if (tag.isNotEmpty()) Text(tag, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
            }
            if (p != null && !p.watched && p.duration > 0) {
                LinearProgressIndicator(
                    progress = { (p.position.toFloat() / p.duration).coerceIn(0f, 1f) },
                    color = Accent,
                    trackColor = PanelHi,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
            }
        }
    }
}

// =====================================================================
//  "Play with..." chooser, shown only while the player setting is "Ask"
// =====================================================================
@Composable
fun PlayChoiceDialog(app: AppState, req: PlayRequest) {
    val ctx = LocalContext.current
    var always by remember { mutableStateOf(false) }
    val first = remember { FocusRequester() }

    fun choose(which: String) {
        if (always) app.setPlayer(which)       // remembered: it will never ask again
        app.ask = null
        app.launch(ctx, which, req)
    }

    Dialog(onDismissRequest = { app.ask = null }) {
        LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
        Column(
            Modifier.clip(RoundedCornerShape(16.dp)).background(Panel).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Play with…", color = TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(req.items[req.start].title, color = Muted, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            ActionButton("▶ This app", Modifier.fillMaxWidth().focusRequester(first), primary = true) { choose("app") }
            ActionButton("Open in VLC", Modifier.fillMaxWidth()) { choose("vlc") }
            Chip(if (always) "✓ Always use my choice" else "Always use my choice", always) { always = !always }
        }
    }
}

// =====================================================================
//  Shown once after a crash, so you can photograph the reason
// =====================================================================
@Composable
fun CrashScreen(text: String, onContinue: () -> Unit) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    Column(Modifier.fillMaxSize().background(Bg).safeDrawingPadding().padding(20.dp)) {
        Text(
            "The app ended unexpectedly last time. Take a photo of this screen and send it to Claude.",
            color = TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            text,
            color = Muted, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
        )
        Spacer(Modifier.height(10.dp))
        ActionButton("Continue", Modifier.focusRequester(first), primary = true, onClick = onContinue)
    }
}
