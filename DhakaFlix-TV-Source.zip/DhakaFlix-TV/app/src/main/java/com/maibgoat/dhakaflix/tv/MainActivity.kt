package com.maibgoat.dhakaflix.tv

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import coil.Coil
import coil.ImageLoader
import coil.memory.MemoryCache
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import java.io.File

class QItem(val url: String, val title: String)

/** What to play: a list of videos (episodes), which one to start with, and where to start. */
class PlayRequest(val items: List<QItem>, val start: Int, val posMs: Long, val parent: String)

sealed interface Screen {
    data object Home : Screen
    class Detail(val title: Title) : Screen
    class Play(val items: List<QItem>, val start: Int, val posMs: Long, val parent: String) : Screen
}

/** Everything the screens share. Lives as long as the activity, so scroll position survives going to a title and back. */
class AppState(private val prefs: SharedPreferences) {
    val stack = mutableStateListOf<Screen>(Screen.Home)

    var section by mutableStateOf(CATEGORIES.firstOrNull()?.name ?: SEC_SEARCH)
    var query by mutableStateOf("")
    var sort by mutableIntStateOf(0)
    var limit by mutableIntStateOf(Lite.page)
    var items by mutableStateOf<List<Title>>(emptyList())
    val gridState = LazyGridState()

    var restoreFocus: String? = null
    val lastSeason = HashMap<String, Int>()

    // Which player to use: "ask" (default), "vlc" or "app". Saved on the device.
    var playerPref by mutableStateOf(prefs.getString("player", "ask") ?: "ask")
    var ask by mutableStateOf<PlayRequest?>(null)      // non-null = show the "Play with..." chooser
    var progressTick by mutableIntStateOf(0)           // bumps when VLC reports where you stopped

    // Posters on/off. Off by default on TVs (lighter); you can switch it on from the tab row.
    var posters by mutableStateOf(prefs.getBoolean("posters", !Lite.on))

    fun push(s: Screen) { stack.add(s) }
    fun back() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }

    fun select(s: String) {
        section = s
        limit = Lite.page
        items = emptyList()
    }

    fun togglePosters() {
        posters = !posters
        prefs.edit().putBoolean("posters", posters).apply()
    }

    fun setPlayer(v: String) {
        playerPref = v
        prefs.edit().putString("player", v).apply()
    }

    fun cyclePlayer() = setPlayer(
        when (playerPref) {
            "ask" -> "vlc"
            "vlc" -> "app"
            else -> "ask"
        }
    )

    /** Play something, respecting the saved player choice. */
    fun play(ctx: Context, req: PlayRequest) {
        when (playerPref) {
            "vlc" -> launch(ctx, "vlc", req)
            "app" -> launch(ctx, "app", req)
            else -> ask = req
        }
    }

    fun launch(ctx: Context, which: String, req: PlayRequest) {
        if (which == "vlc") {
            val q = req.items[req.start]
            Vlc.start(ctx, q.url, q.title, req.posMs, req.parent)    // VLC plays one video at a time
        } else {
            push(Screen.Play(req.items, req.start, req.posMs, req.parent))
        }
    }
}

class MainActivity : ComponentActivity() {

    // While the app is open we save a tiny "last known state" note every 2 s. A normal exit deletes it.
    // If it is still there on the next start, the app was killed, crashed or the TV restarted, and it tells us why.
    private val ui = Handler(Looper.getMainLooper())
    private var crumbFile: File? = null
    private val crumbTick = object : Runnable {
        override fun run() {
            try {
                crumbFile?.writeText(Diag.snapshot(this@MainActivity))
            } catch (x: Throwable) {
            }
            ui.postDelayed(this, 2000)
        }
    }

    override fun onStart() {
        super.onStart()
        crumbTick.run()
    }

    override fun onStop() {
        super.onStop()
        ui.removeCallbacks(crumbTick)
        crumbFile?.delete()
    }

    /** Short, photo-friendly version of a crash report. */
    private fun summarize(trace: String): String {
        val lines = trace.lines()
        val picked = lines.take(6) +
            lines.filter { it.startsWith("Caused by") } +
            lines.filter { "dhakaflix" in it }.take(8)
        return picked.distinct().joinToString("\n").take(1800)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // If the app crashes, remember why; the next start shows it so you can photograph it.
        val crashFile = File(filesDir, "crash.txt")
        val oldHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            try {
                crashFile.writeText("Thread: ${thread.name}\n" + Log.getStackTraceString(e))
            } catch (x: Throwable) {
            }
            oldHandler?.uncaughtException(thread, e)
        }
        val crumb = File(filesDir, "breadcrumb.txt")
        crumbFile = crumb
        val crashPart = if (crashFile.exists()) "CRASH:\n" + summarize(crashFile.readText()) else null
        val deathPart = if (crumb.exists()) "LAST STATE WHILE THE APP WAS OPEN:\n" + crumb.readText().take(700) else null
        crumb.delete()
        val lastCrash: String? = listOfNotNull(crashPart, deathPart).joinToString("\n\n").ifEmpty { null }

        Lite.on = isTv(this)
        Repo.init(applicationContext, Lite.on)

        // Poster loader: gentle with the ISP server, and extra light on TVs.
        val client = OkHttpClient.Builder()
            .dispatcher(Dispatcher().apply { maxRequestsPerHost = 3; maxRequests = 8 })
            .build()
        val loader = ImageLoader.Builder(this)
            .okHttpClient(client)
            .respectCacheHeaders(false)
            .crossfade(!Lite.on)
            .allowHardware(!Lite.on)
        if (Lite.on) loader.memoryCache { MemoryCache.Builder(this).maxSizePercent(0.12).build() }
        Coil.setImageLoader(loader.build())

        val app = AppState(getSharedPreferences("settings", Context.MODE_PRIVATE))

        // When VLC closes it tells us where you stopped, so "Continue watching" keeps working.
        Vlc.launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            Vlc.onResult(res.data) { app.progressTick++ }
        }

        setContent {
            AppTheme {
                var crash by remember { mutableStateOf(lastCrash) }
                val c = crash
                if (c != null) {
                    CrashScreen(c) {
                        crashFile.delete()
                        crash = null
                    }
                } else {
                    LaunchedEffect(Unit) { Repo.scan() }     // starts only after the crash screen (if any) is dismissed
                    BackHandler(enabled = app.stack.size > 1 && app.stack.last() !is Screen.Play) { app.back() }
                    when (val s = app.stack.last()) {
                        is Screen.Home -> HomeScreen(app)
                        is Screen.Detail -> DetailScreen(app, s.title)
                        is Screen.Play -> PlayerScreen(app, s)
                    }
                    val req = app.ask
                    if (req != null) PlayChoiceDialog(app, req)
                }
            }
        }
    }
}
