const $ = s => document.querySelector(s);
const state = { titles:[], category:'All', query:'', sort:'latest', resolved:new Map(), current:null };
const grid = $('#grid'), statusEl = $('#status');
const enc = value => encodeURIComponent(value);
const streamUrl = url => `/stream?url=${enc(url)}`;
function setStatus(text, error=false){ statusEl.textContent=text; statusEl.classList.toggle('error',error); }
function safeText(s){ return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function visibleTitles(){
  let list = state.titles.filter(t => (state.category==='All'||t.category===state.category) && (!state.query || `${t.name} ${t.year} ${t.category}`.toLowerCase().includes(state.query.toLowerCase())));
  if(state.sort==='az') list.sort((a,b)=>a.name.localeCompare(b.name));
  else if(state.sort==='year') list.sort((a,b)=>b.year-a.year);
  else list.sort((a,b)=>b.year-a.year || a.name.localeCompare(b.name));
  return list;
}
function render(){
  const list=visibleTitles(); $('#sectionTitle').textContent=state.category==='All'?'Discover':state.category;
  grid.innerHTML='';
  if(!list.length){ grid.innerHTML='<div class="empty">No titles found. Check your ISP connection or try another category.</div>'; return; }
  const frag=document.createDocumentFragment();
  list.forEach(t=>{
    const card=document.createElement('button'); card.className='movie-card'; card.type='button';
    const cached=state.resolved.get(t.href);
    card.innerHTML=`<div class="poster"><span>DF</span>${cached?.poster?`<img loading="lazy" src="${streamUrl(cached.poster)}" alt="">`:''}${t.quality?`<span class="quality">${safeText(t.quality)}</span>`:''}${t.kind==='series'?'<span class="kind">SERIES</span>':''}</div><h3>${safeText(t.name)}</h3><p>${t.year} · ${safeText(t.category)}</p>`;
    card.addEventListener('click',()=>openDetail(t)); frag.appendChild(card);
  });
  grid.appendChild(frag);
}
function renderTabs(){
  const cats=['All',...new Set(state.titles.map(t=>t.category))];
  $('#categories').innerHTML=cats.map(c=>`<button class="tab ${state.category===c?'active':''}" data-category="${safeText(c)}">${safeText(c)}</button>`).join('');
  $('#categories').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{state.category=b.dataset.category;renderTabs();render();}));
}
async function api(path){
  let r;
  try { r = await fetch(path); }
  catch { throw new Error('The media bridge is not reachable. The GitHub Pages website is online, but scanning requires the separate ISP-network bridge.'); }
  const type = r.headers.get('content-type') || '';
  if (!type.includes('application/json')) {
    throw new Error('The website is hosted successfully, but GitHub Pages does not provide the media API. Media scanning needs the separate ISP-network bridge.');
  }
  const data = await r.json();
  if(!r.ok) throw new Error(data.error||`HTTP ${r.status}`);
  return data;
}
async function scan(){
  $('#rescan').disabled=true; setStatus('Connecting to your ISP media servers and scanning folders…');
  try{const data=await api('/api/scan');state.titles=data.titles;state.resolved.clear();renderTabs();render();setStatus(`${data.titles.length.toLocaleString()} titles found${data.failed?` · ${data.failed} folders could not be reached`:''}.`+(data.titles.length?'':' No titles found.'));}
  catch(e){setStatus(`Could not scan: ${e.message}. Confirm you are on the ISP network and the server URLs are correct.`,true);}
  finally{$('#rescan').disabled=false;}
}
async function resolve(t){if(state.resolved.has(t.href))return state.resolved.get(t.href);const d=await api(`/api/resolve?url=${enc(t.href)}&series=${t.kind==='series'?1:0}`);state.resolved.set(t.href,d);return d;}
function openDetail(t){
  state.current=t;$('#homeView').classList.add('hidden');$('#detailView').classList.remove('hidden');$('#detailTitle').textContent=t.name;$('#detailCategory').textContent=t.category.toUpperCase();$('#detailMeta').textContent=[t.year,t.quality,t.dual?'Dual/Multi Audio':'',t.kind==='series'?'TV Series':'Movie'].filter(Boolean).join(' · ');$('#detailDesc').textContent='Loading files from your ISP server…';$('#detailPoster').innerHTML='<span>DF</span>';$('#detailActions').innerHTML='';$('#seasonArea').innerHTML='';
  resolve(t).then(d=>{
    if(state.current?.href!==t.href)return;
    if(d.poster)$('#detailPoster').innerHTML=`<img src="${streamUrl(d.poster)}" alt="${safeText(t.name)} poster">`;
    $('#detailDesc').textContent=d.video?'Video file found. Use Play to test browser playback.':'Folder opened. Choose a season or episode below.';
    if(d.video){$('#detailActions').innerHTML=`<button class="play" id="playTitle">▶ Play</button><button id="openFile">Open video URL</button>`;$('#playTitle').onclick=()=>playVideo(d.video,t.name);$('#openFile').onclick=()=>window.open(streamUrl(d.video),'_blank','noopener');}
    if(t.kind==='series'){
      const dirs=d.entries.filter(e=>e.dir).sort((a,b)=>a.name.localeCompare(b.name,undefined,{numeric:true}));
      const files=d.entries.filter(e=>e.video);
      $('#seasonArea').innerHTML='<h3>Seasons & episodes</h3><div class="season-list" id="seasonList"></div><div class="episode-list" id="episodeList"></div>';
      const seasonList=$('#seasonList');
      if(files.length){const b=document.createElement('button');b.className='season-btn';b.textContent='Episodes';b.onclick=()=>showEpisodes(files);seasonList.appendChild(b);}
      dirs.forEach(dir=>{const b=document.createElement('button');b.className='season-btn';b.textContent=dir.name;b.onclick=async()=>{try{const eps=(await api(`/api/list?url=${enc(dir.url)}`)).filter(e=>e.video);showEpisodes(eps);}catch(e){$('#episodeList').textContent=e.message;}};seasonList.appendChild(b);});
      if(!dirs.length&&!files.length)$('#seasonArea').insertAdjacentHTML('beforeend','<p class="detail-desc">No season folders or video files detected.</p>');
    }
  }).catch(e=>{$('#detailDesc').textContent=`Could not open this folder: ${e.message}`;});
}
function showEpisodes(eps){const box=$('#episodeList');box.innerHTML='';if(!eps.length){box.textContent='No video files found in this folder.';return;}eps.sort((a,b)=>a.name.localeCompare(b.name,undefined,{numeric:true}));eps.forEach(e=>{const row=document.createElement('div');row.className='episode';const name=document.createElement('span');name.textContent=e.name;const btn=document.createElement('button');btn.textContent='Play';btn.onclick=()=>playVideo(e.url,e.name);row.append(name,btn);box.appendChild(row);});}
function playVideo(url,name){$('#playerName').textContent=name;const v=$('#video');v.src=streamUrl(url);$('#playerModal').classList.remove('hidden');v.load();v.play().catch(()=>{});}
function closeDetail(){$('#detailView').classList.add('hidden');$('#homeView').classList.remove('hidden');state.current=null;}
$('#rescan').addEventListener('click',scan);$('#explore').addEventListener('click',()=>document.querySelector('.tabs').scrollIntoView({behavior:'smooth'}));$('#back').addEventListener('click',closeDetail);
$('#searchToggle').addEventListener('click',()=>{$('#searchPanel').classList.toggle('hidden');if(!$('#searchPanel').classList.contains('hidden'))$('#searchInput').focus();});
$('#searchInput').addEventListener('input',e=>{state.query=e.target.value;render();});$('#clearSearch').addEventListener('click',()=>{$('#searchInput').value='';state.query='';render();});$('#sort').addEventListener('change',e=>{state.sort=e.target.value;render();});
$('#closePlayer').addEventListener('click',()=>{const v=$('#video');v.pause();v.removeAttribute('src');v.load();$('#playerModal').classList.add('hidden');});
scan();
