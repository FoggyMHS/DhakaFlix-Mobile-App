# DhakaFlix Web — GitHub Pages package

This package adds a static PWA shell to the existing `FoggyMHS/DhakaFlix-Mobile-App` repository.
It does not overwrite the Android or TV APK/source files.

## Upload these two items to the repository root

- The `web/` folder
- The `.github/workflows/dhakaflix-pages.yml` workflow file

Keep the folder paths exactly as shown. Do not upload the contents of `web/` directly into the repository root.

## Enable GitHub Pages once

1. Open https://github.com/FoggyMHS/DhakaFlix-Mobile-App
2. Upload the `web` folder and `.github/workflows/dhakaflix-pages.yml` (using GitHub's Add file / Upload files interface; preserve the folder paths).
3. Commit the changes to the `main` branch.
4. Open **Settings → Pages**.
5. Under **Build and deployment → Source**, choose **GitHub Actions**.
6. Open the **Actions** tab and wait for **Deploy DhakaFlix Web to GitHub Pages** to finish successfully.
7. Your expected website address is:
   https://foggymhs.github.io/DhakaFlix-Mobile-App/

If GitHub asks to enable Pages or approve a workflow permission, follow the on-screen prompt. You only need to configure Pages once.

## What this package does

- Publishes the current browser prototype UI from the supplied `DhakaFlix-Web-Test.zip` snapshot.
- Adds an installable PWA manifest, app icons, and an offline app-shell cache.
- Uses relative paths so the app can live under the repository's GitHub Pages URL.
- Keeps API and video responses out of the service-worker cache.
- Gives a clear message when the static website cannot reach the separate media bridge.

## Important limitation

GitHub Pages is static hosting. It cannot run `server.js`, scan ISP folders, proxy HTTP media, or stream videos. The current UI's media scanning and playback require a separate backend/bridge running on a device or server that can access the ISP network. This package does not include or expose that bridge.

The original ZIP snapshot was used as the source because the newer Termux `app.js` output was incomplete in the chat. If you made additional changes in Termux after creating that ZIP, those changes are not included in this package.

## Updating later

Replace files inside `web/` with newer web source, commit to `main`, and the workflow will redeploy automatically.
