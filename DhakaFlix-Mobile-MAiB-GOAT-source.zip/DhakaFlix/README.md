# DhakaFlix Mobile

A mobile-first Android client for browsing and playing media hosted on supported local ISP FTP/HTTP directory servers. The interface is inspired by streaming apps: a featured title, horizontal poster shelves, search, a thumb-friendly bottom navigation bar, title details, series episodes, watch progress, and an in-app/VLC player choice.

**Publisher credit:** MAiB_GOAT  
**Application ID:** `com.maibgoat.dhakaflix`  
**Minimum Android:** Android 7.0 (API 24)

## Important project notes

- This edition is mobile-only. Android TV launcher support has been removed.
- The old application ID and old signing key are intentionally not reused. Android treats this as a separate app, so install it alongside the old DhakaFlix or uninstall the old app first.
- The new release signing key is delivered separately. It is deliberately excluded from this repository.
- Do not change or regenerate the signing key after publishing the first release. Keep at least two secure backups.
- The app needs access to the configured local media server. Some ISP servers use plain HTTP, so cleartext traffic is enabled for compatibility.

## Configure your ISP folders

Edit `app/src/main/java/com/maibgoat/dhakaflix/Data.kt` and update the `CATEGORIES` list near the top with the exact directory URLs that work on your ISP connection. A folder URL should open in a browser while connected to that ISP network.

## Build a debug APK

Use Android Studio with JDK 17 and Android SDK 35, or a compatible Gradle 8.11.1 installation:

```bash
gradle assembleDebug
```

The debug APK is generated at:

`app/build/outputs/apk/debug/app-debug.apk`

## Build a signed release APK

Set these environment variables before running the release build. Keep the keystore outside the repository.

```bash
export DHAKAFLIX_STORE_FILE="/absolute/path/to/DhakaFlix-MAiB-GOAT-release.jks"
export DHAKAFLIX_STORE_PASSWORD="YOUR_STORE_PASSWORD"
export DHAKAFLIX_KEY_ALIAS="maibgoat"
export DHAKAFLIX_KEY_PASSWORD="YOUR_KEY_PASSWORD"
gradle assembleRelease
```

The signed APK is generated at:

`app/build/outputs/apk/release/app-release.apk`

## GitHub Actions build from a phone

A manual workflow is included at `.github/workflows/build-release.yml`. Add these repository **Actions secrets** before running it:

- `SIGNING_KEY_BASE64`: Base64 encoding of the `.jks` file
- `SIGNING_STORE_PASSWORD`: keystore password
- `SIGNING_KEY_ALIAS`: `maibgoat`
- `SIGNING_KEY_PASSWORD`: key password

Then open **Actions → Build signed release → Run workflow**. Download the APK from the workflow artifact. Never commit the keystore or passwords.

To create the Base64 secret locally:

```bash
base64 -w 0 DhakaFlix-MAiB-GOAT-release.jks
```

On Android/Termux, `base64` may not support `-w 0`; use `base64 DhakaFlix-MAiB-GOAT-release.jks | tr -d '\n'` instead.

## Updating later

Increase `versionCode` and `versionName` in `app/build.gradle.kts`, build with the exact same keystore and alias, then publish the new APK. Android will accept it as an update only if the package ID and signing identity remain the same.

## License

MIT. See [LICENSE](LICENSE).
