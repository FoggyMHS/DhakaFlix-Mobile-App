plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.maibgoat.dhakaflix"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.maibgoat.dhakaflix"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildFeatures { compose = true }

    // Signing credentials are supplied locally through Gradle properties or environment variables.
    // Never commit the keystore or credentials to a public repository.
    val signingStore = providers.gradleProperty("DHAKAFLIX_STORE_FILE").orNull
        ?: System.getenv("DHAKAFLIX_STORE_FILE")
    val signingStorePassword = providers.gradleProperty("DHAKAFLIX_STORE_PASSWORD").orNull
        ?: System.getenv("DHAKAFLIX_STORE_PASSWORD")
    val signingKeyAlias = providers.gradleProperty("DHAKAFLIX_KEY_ALIAS").orNull
        ?: System.getenv("DHAKAFLIX_KEY_ALIAS")
    val signingKeyPassword = providers.gradleProperty("DHAKAFLIX_KEY_PASSWORD").orNull
        ?: System.getenv("DHAKAFLIX_KEY_PASSWORD")

    if (listOf(signingStore, signingStorePassword, signingKeyAlias, signingKeyPassword).all { !it.isNullOrBlank() }) {
        signingConfigs {
            create("releaseKey") {
                storeFile = file(signingStore!!)
                storePassword = signingStorePassword
                keyAlias = signingKeyAlias
                keyPassword = signingKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (listOf(signingStore, signingStorePassword, signingKeyAlias, signingKeyPassword).all { !it.isNullOrBlank() }) {
                signingConfig = signingConfigs.getByName("releaseKey")
            }
        }
        debug { }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
