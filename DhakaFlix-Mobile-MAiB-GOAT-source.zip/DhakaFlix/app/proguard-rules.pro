# Nothing special needed. If the release APK crashes on start,
# set isMinifyEnabled = false in app/build.gradle.kts and rebuild.
