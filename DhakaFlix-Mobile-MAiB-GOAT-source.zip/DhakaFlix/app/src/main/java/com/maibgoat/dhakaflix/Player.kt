@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.maibgoat.dhakaflix

import android.content.pm.ActivityInfo
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

/** Audio language to pick automatically when a file has several tracks (en, hi, bn ...). Change if you like. */
const val PREFERRED_AUDIO = "en"

private fun saveNow(exo: ExoPlayer, cur: QItem, parent: String) {
    val dur = exo.duration
    val pos = exo.currentPosition
    if (dur <= 0L || dur == C.TIME_UNSET) return
    val watched = pos > dur * 0.95
    if (!watched && pos < 10_000L) return
    Repo.saveProgress(cur.url, parent, if (watched) 0L else pos, dur, watched)
}

@Composable
fun PlayerScreen(app: AppState, p: Screen.Play) {
    val ctx = LocalContext.current
    val activity = remember { ctx.findActivity() as ComponentActivity }

    var cur by remember { mutableStateOf(p.items[p.start]) }
    var issue by remember { mutableStateOf<String?>(null) }
    var pv by remember { mutableStateOf<PlayerView?>(null) }
    val issueFocus = remember { FocusRequester() }

    val exo = remember {
        ExoPlayer.Builder(ctx).build().apply {
            trackSelectionParameters = trackSelectionParameters.buildUpon()
                .setPreferredAudioLanguage(PREFERRED_AUDIO)
                .setIgnoredTextSelectionFlags(C.SELECTION_FLAG_DEFAULT)   // subtitles off until you pick one
                .build()
            setMediaItems(
                p.items.map { MediaItem.Builder().setUri(it.url).setMediaId(it.url).build() },
                p.start,
                p.posMs,
            )
            prepare()
            playWhenReady = true
        }
    }

    // Landscape + fullscreen while playing; restore afterwards.
    DisposableEffect(Unit) {
        val w = activity.window
        val ctl = WindowCompat.getInsetsController(w, w.decorView)
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctl.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            ctl.show(WindowInsetsCompat.Type.systemBars())
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Player events + pause when the app goes to the background + save and release when leaving.
    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) Repo.markWatched(cur.url, p.parent)
                val id = mediaItem?.mediaId
                p.items.firstOrNull { it.url == id }?.let { cur = it }
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    Repo.markWatched(cur.url, p.parent)
                    app.back()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                issue = "This file can't be played here (${error.errorCodeName})."
            }

            override fun onTracksChanged(tracks: Tracks) {
                val audio = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
                if (audio.isNotEmpty() && audio.none { it.isSupported }) {
                    issue = "This file's audio format isn't supported on this device, so it would play without sound."
                    exo.pause()
                }
            }
        }
        exo.addListener(listener)

        val observer = object : DefaultLifecycleObserver {
            override fun onPause(owner: LifecycleOwner) {
                saveNow(exo, cur, p.parent)
                exo.pause()
            }
        }
        activity.lifecycle.addObserver(observer)

        onDispose {
            activity.lifecycle.removeObserver(observer)
            exo.removeListener(listener)
            saveNow(exo, cur, p.parent)
            exo.release()
        }
    }

    // Remember where you are every 15 seconds.
    LaunchedEffect(exo) {
        while (true) {
            delay(15_000)
            saveNow(exo, cur, p.parent)
        }
    }

    LaunchedEffect(issue) {
        if (issue != null) runCatching { issueFocus.requestFocus() }
    }

    // Back: first press hides the controls, second press leaves the player.
    BackHandler {
        val v = pv
        if (issue == null && v != null && v.isControllerFullyVisible) v.hideController() else app.back()
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                PlayerView(c).apply {
                    player = exo
                    controllerShowTimeoutMs = 4000
                    setShowSubtitleButton(true)
                    setShowNextButton(p.items.size > 1)
                    setShowPreviousButton(p.items.size > 1)
                    keepScreenOn = true
                    isFocusable = true
                    post { requestFocus() }      // so the TV remote controls the player
                    pv = this
                }
            },
        )

        val msg = issue
        if (msg != null) {
            Box(Modifier.fillMaxSize().background(Color(0xE6000000)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                    Text(msg, color = Color.White, fontSize = 16.sp)
                    Row(Modifier.padding(top = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        ActionButton("Open in VLC", Modifier.focusRequester(issueFocus), primary = true) {
                            Vlc.start(ctx, cur.url, cur.title, exo.currentPosition, p.parent)
                            app.back()
                        }
                        ActionButton("Play anyway") {
                            issue = null
                            exo.play()
                            pv?.requestFocus()
                        }
                        ActionButton("Back") { app.back() }
                    }
                }
            }
        }
    }
}
