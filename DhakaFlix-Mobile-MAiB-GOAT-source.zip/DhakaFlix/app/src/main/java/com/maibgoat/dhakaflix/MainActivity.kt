package com.maibgoat.dhakaflix

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import coil.Coil
import coil.ImageLoader
import okhttp3.Dispatcher
import okhttp3.OkHttpClient

class QItem(val url: String, val title: String)

/** What to play: a list of videos (episodes), which one to start with, and where to start. */
class PlayRequest(val items: List<QItem>, val start: Int, val posMs: Long, val parent: String)

sealed interface Screen {
    data object Home : Screen
    data object Settings : Screen
    class Detail(val title: Title) : Screen
    class Play(val items: List<QItem>, val start: Int, val posMs: Long, val parent: String) : Screen
}

/** Everything the screens share. Lives as long as the activity, so scroll position survives going to a title and back. */
class AppState(private val prefs: SharedPreferences) {
    val stack = mutableStateListOf<Screen>(Screen.Home)

    var section by mutableStateOf(CATEGORIES.firstOrNull()?.name ?: SEC_SEARCH)
    var query by mutableStateOf("")
    var sort by mutableIntStateOf(0)
    var limit by mutableIntStateOf(300)
    var items by mutableStateOf<List<Title>>(emptyList())
    val gridState = LazyGridState()

    var restoreFocus: String? = null
    val lastSeason = HashMap<String, Int>()

    // Which player to use: "ask" (default), "vlc" or "app". Saved on the device.
    var playerPref by mutableStateOf(prefs.getString("player", "ask") ?: "ask")
    var ask by mutableStateOf<PlayRequest?>(null)      // non-null = show the "Play with..." chooser
    var progressTick by mutableIntStateOf(0)           // bumps when VLC reports where you stopped

    fun push(s: Screen) { stack.add(s) }
    fun back() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }

    fun select(s: String) {
        section = s
        limit = 300
        items = emptyList()
    }

    fun setPlayer(v: String) {
        playerPref = v
        prefs.edit().putString("player", v).apply()
    }

    fun cyclePlayer() = setPlayer(
        when (playerPref) {
            "ask" -> "vlc"
            "vlc" -> "app"
            else -> "ask"
        }
    )

    /** Play something, respecting the saved player choice. */
    fun play(ctx: Context, req: PlayRequest) {
        when (playerPref) {
            "vlc" -> launch(ctx, "vlc", req)
            "app" -> launch(ctx, "app", req)
            else -> ask = req
        }
    }

    fun launch(ctx: Context, which: String, req: PlayRequest) {
        if (which == "vlc") {
            val q = req.items[req.start]
            Vlc.start(ctx, q.url, q.title, req.posMs, req.parent)    // VLC plays one video at a time
        } else {
            push(Screen.Play(req.items, req.start, req.posMs, req.parent))
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Repo.init(applicationContext)
        Repo.scan()                                   // quick when nothing changed; first run takes a few minutes

        // Poster loader: be gentle with the ISP server (max 3 at once) and cache images even if the server says not to.
        val client = OkHttpClient.Builder()
            .dispatcher(Dispatcher().apply { maxRequestsPerHost = 3; maxRequests = 8 })
            .build()
        Coil.setImageLoader(
            ImageLoader.Builder(this)
                .okHttpClient(client)
                .respectCacheHeaders(false)
                .crossfade(true)
                .build()
        )

        val app = AppState(getSharedPreferences("settings", Context.MODE_PRIVATE))

        // When VLC closes it tells us where you stopped, so "Continue watching" keeps working.
        Vlc.launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            Vlc.onResult(res.data) { app.progressTick++ }
        }

        setContent {
            AppTheme {
                BackHandler(enabled = app.stack.size > 1 && app.stack.last() !is Screen.Play) { app.back() }
                when (val s = app.stack.last()) {
                    is Screen.Home -> HomeScreen(app)
                    is Screen.Settings -> SettingsScreen(app)
                    is Screen.Detail -> DetailScreen(app, s.title)
                    is Screen.Play -> PlayerScreen(app, s)
                }
                val req = app.ask
                if (req != null) PlayChoiceDialog(app, req)
            }
        }
    }
}
