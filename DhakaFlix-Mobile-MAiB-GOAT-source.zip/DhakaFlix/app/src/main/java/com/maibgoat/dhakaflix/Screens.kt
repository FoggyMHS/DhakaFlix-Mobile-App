package com.maibgoat.dhakaflix

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

// =====================================================================
//  MOBILE HOME: Netflix-inspired hero, horizontal shelves and bottom nav
// =====================================================================
@Composable
fun HomeScreen(app: AppState) {
    val tick by Repo.tick.collectAsState()
    val scanning by Repo.scanning.collectAsState()
    val status by Repo.status.collectAsState()
    val wide = LocalConfiguration.current.screenWidthDp >= 600
    val selectedCategory = app.section
    val isSearch = selectedCategory == SEC_SEARCH

    LaunchedEffect(app.section, app.query, app.sort, app.limit, tick) {
        if (isSearch) delay(250)
        app.items = Repo.query(app.section, app.query, app.sort, app.limit)
    }

    val sections = listOf(SEC_CONTINUE) + CATEGORIES.map { it.name }
    val featured = app.items.firstOrNull()

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxSize().safeDrawingPadding()) {
            // Compact top app bar
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Dhaka", color = TextHi, fontSize = 23.sp, fontWeight = FontWeight.Black)
                Text("Flix", color = Accent, fontSize = 23.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                Text("⌕", color = TextHi, fontSize = 28.sp, modifier = Modifier.clickable { app.select(SEC_SEARCH) }.padding(horizontal = 10.dp))
                Text("⚙", color = TextHi, fontSize = 22.sp, modifier = Modifier.clickable { app.push(Screen.Settings) }.padding(start = 10.dp))
            }

            if (!isSearch && selectedCategory != SEC_CONTINUE) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    items(listOf("Latest", "A–Z", "Year").mapIndexed { index, label -> index to label }) { (index, label) ->
                        Chip(label, app.sort == index) { app.sort = index; app.limit = 300 }
                    }
                }
            }

            if (isSearch) {
                OutlinedTextField(
                    value = app.query,
                    onValueChange = { app.query = it; app.limit = 300 },
                    singleLine = true,
                    placeholder = { Text("Search movies and series") },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp),
                )
            } else {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    items(sections) { section ->
                        Chip(section, selectedCategory == section) { app.select(section) }
                    }
                    item { Chip("Search", false) { app.select(SEC_SEARCH) } }
                }
            }

            if (status.isNotEmpty()) Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))

            if (app.items.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (scanning) "Finding your next watch…" else if (isSearch) "Search your library" else "Your library is waiting", color = TextHi, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            when { scanning -> "Titles will appear as the server is scanned"; isSearch -> "Try a movie or series title"; selectedCategory == SEC_CONTINUE -> "Nothing in progress yet"; else -> "Connect to your ISP Wi-Fi, then scan again" },
                            color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)
                        )
                        if (!scanning && !isSearch) ActionButton("Rescan library", primary = true) { Repo.scan(full = true) }
                    }
                }
            } else if (isSearch || selectedCategory == SEC_CONTINUE) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(if (wide) 150.dp else 112.dp),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 28.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(app.items, key = { it.href }) { title -> PosterCard(title) { app.push(Screen.Detail(title)) } }
                }
            } else {
                // Hero + category shelves. Keep the content scrollable on compact phones.
                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 28.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    if (featured != null) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(if (wide) 330.dp else 270.dp).clip(RoundedCornerShape(18.dp)).background(Panel)) {
                                val heroUrl = featured.poster
                                if (heroUrl != null) AsyncImage(model = heroUrl, contentDescription = featured.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Bg.copy(alpha = .98f)))))
                                Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
                                    Text("FEATURED IN YOUR LIBRARY", color = Color.White.copy(alpha = .8f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text(featured.name, color = Color.White, fontSize = if (wide) 27.sp else 23.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 5.dp))
                                    Text(listOfNotNull(featured.year.takeIf { it > 0 }?.toString(), featured.quality.takeIf { it.isNotBlank() }, if (featured.isSeries) "Series" else "Movie").joinToString("  •  "), color = Color.White.copy(alpha = .8f), fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                                    ActionButton("▶  Explore", primary = true, modifier = Modifier.padding(top = 12.dp)) { app.push(Screen.Detail(featured)) }
                                }
                            }
                        }
                    }
                    item { Shelf("Recently added", app.items.take(18), wide) { app.push(Screen.Detail(it)) } }
                    if (app.items.size > 18) item { Shelf("More to discover", app.items.drop(18).take(18), wide) { app.push(Screen.Detail(it)) } }
                    if (app.items.size > 36) item { Shelf("Keep exploring", app.items.drop(36).take(18), wide) { app.push(Screen.Detail(it)) } }
                    item {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Library tools", color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.weight(1f))
                            ActionButton("Rescan") { Repo.scan(full = true) }
                        }
                    }
                }
            }

            // Native-feeling, thumb-reachable navigation
            Row(
                Modifier.fillMaxWidth().background(Color(0xFF101013)).padding(horizontal = 10.dp, vertical = 9.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BottomItem("⌂", "Home", selectedCategory == CATEGORIES.firstOrNull()?.name || selectedCategory in CATEGORIES.map { it.name }) { app.select(CATEGORIES.firstOrNull()?.name ?: SEC_SEARCH) }
                BottomItem("▤", "Continue", selectedCategory == SEC_CONTINUE) { app.select(SEC_CONTINUE) }
                BottomItem("⌕", "Search", isSearch) { app.select(SEC_SEARCH) }
                BottomItem("⚙", "Settings", false) { app.push(Screen.Settings) }
            }
        }
    }
}

@Composable
private fun Shelf(title: String, titles: List<Title>, wide: Boolean, onOpen: (Title) -> Unit) {
    if (titles.isEmpty()) return
    Column {
        Text(title, color = TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 18.dp, bottom = 10.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            items(titles, key = { it.href }) { titleItem ->
                Column(Modifier.width(if (wide) 142.dp else 116.dp)) {
                    PosterCard(titleItem, onClick = { onOpen(titleItem) })
                }
            }
        }
    }
}

@Composable
private fun BottomItem(symbol: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 2.dp)) {
        Text(symbol, color = if (selected) Accent else Muted, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text(label, color = if (selected) TextHi else Muted, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun SettingsScreen(app: AppState) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().background(Bg).safeDrawingPadding().padding(horizontal = 20.dp, vertical = 16.dp)) {
        ActionButton("← Back") { app.back() }
        Text("Settings", color = TextHi, fontSize = 28.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 22.dp, bottom = 18.dp))
        Text("PLAYBACK", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text("Preferred player", color = TextHi, fontSize = 16.sp, modifier = Modifier.padding(top = 10.dp))
        Text("Choose how videos open when you press Play.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp, bottom = 10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Ask", app.playerPref == "ask") { app.setPlayer("ask") }
            Chip("In-app", app.playerPref == "app") { app.setPlayer("app") }
            Chip("VLC", app.playerPref == "vlc") { app.setPlayer("vlc") }
        }
        Text("LIBRARY", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 28.dp))
        Text("Refresh your library", color = TextHi, fontSize = 16.sp, modifier = Modifier.padding(top = 10.dp))
        Text("Scan the configured ISP media folders for new titles.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp, bottom = 10.dp))
        ActionButton("Rescan library", primary = true) { Repo.scan(full = true) }
        Spacer(Modifier.weight(1f))
        Text("ABOUT", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text("DhakaFlix", color = TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 9.dp))
        Text("A local streaming library companion", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
        Text("Publisher: MAiB_GOAT", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
        Text("Made for mobile", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
    }
}

// =====================================================================
//  DETAIL: poster, rating, plot, Play / Resume, VLC, and seasons for shows
// =====================================================================
@Composable
fun DetailScreen(app: AppState, t0: Title) {
    val ctx = LocalContext.current
    val tv = remember { isTv(ctx) }
    val wide = LocalConfiguration.current.screenWidthDp >= 600
    var t by remember { mutableStateOf(t0) }
    var meta by remember { mutableStateOf<Meta?>(null) }
    var prog by remember { mutableStateOf<Prog?>(null) }
    var ready by remember { mutableStateOf(false) }
    val firstFocus = remember { FocusRequester() }

    LaunchedEffect(t0.href) {
        val r = Repo.resolve(t0.href)
        if (r != null) t = r
    }
    LaunchedEffect(t0.href) { meta = Cinemeta.load(t0) }
    LaunchedEffect(t.video, t.resolved, app.progressTick) {
        val v = t.video
        if (!t.isSeries) {
            if (v != null) prog = Repo.progressOf(listOf(v))[v]
            if (v != null || t.resolved) ready = true
        }
    }
    LaunchedEffect(ready) { if (tv && ready) runCatching { firstFocus.requestFocus() } }

    val m = meta
    val resumePos: Long? = prog?.let { if (!it.watched && it.position > 10_000) it.position else null }

    fun play(fromStart: Boolean) {
        val v = t.video ?: return
        val pos = if (fromStart) 0L else (resumePos ?: 0L)
        app.play(ctx, PlayRequest(listOf(QItem(v, t.name)), 0, pos, t.href))
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        val bgUrl = m?.background
        if (bgUrl != null) {
            AsyncImage(
                model = bgUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = 0.30f,
                modifier = Modifier.fillMaxWidth().height(280.dp),
            )
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Bg)))
            )
        }

        Column(
            Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            ActionButton("← Back") { app.back() }
            Spacer(Modifier.height(14.dp))

            Row {
                val posterUrl = t.poster
                if (posterUrl != null) {
                    AsyncImage(
                        model = posterUrl,
                        contentDescription = t.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .width(if (wide) 180.dp else 110.dp)
                            .aspectRatio(2f / 3f)
                            .clip(RoundedCornerShape(10.dp)),
                    )
                    Spacer(Modifier.width(16.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(t.name, color = TextHi, fontSize = if (wide) 30.sp else 22.sp, fontWeight = FontWeight.Bold)
                    val info = buildList {
                        if (t.year > 0) add(t.year.toString())
                        if (t.quality.isNotEmpty()) add(t.quality)
                        if (t.dual) add("Dual audio")
                        m?.rating?.let { add("IMDb $it") }
                        m?.runtime?.let { add(it) }
                    }.joinToString("  ·  ")
                    if (info.isNotEmpty()) Text(info, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    if (m != null && m.genres.isNotEmpty()) {
                        Text(m.genres.joinToString(", "), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            if (!t.isSeries) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    val v = t.video
                    if (v != null) {
                        ActionButton(
                            if (resumePos != null) "▶ Resume ${fmtTime(resumePos)}" else "▶ Play",
                            Modifier.focusRequester(firstFocus),
                            primary = true,
                        ) { play(false) }
                        if (resumePos != null) ActionButton("Restart") { play(true) }
                        ActionButton("Open in VLC") { app.launch(ctx, "vlc", PlayRequest(listOf(QItem(v, t.name)), 0, resumePos ?: 0L, t.href)) }
                    } else if (t.resolved) {
                        Text("No video file found in this folder.", color = Muted)
                    } else {
                        Text("Loading…", color = Muted)
                    }
                }
            }

            val plot = m?.plot
            if (plot != null) Text(plot, color = TextHi, fontSize = 14.sp, modifier = Modifier.padding(top = 16.dp))
            if (m != null && m.cast.isNotEmpty()) {
                Text("Cast: " + m.cast.take(6).joinToString(", "), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
            }
            if (m?.director != null) Text("Director: ${m.director}", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))

            if (t.isSeries) SeriesSection(app, t, m, firstFocus, tv)

            if (m != null) Text("Details: Cinemeta / IMDb", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 24.dp))
        }
    }
}

// =====================================================================
//  SERIES: season chips + episode list (episodes are listed only when opened)
// =====================================================================
@Composable
fun SeriesSection(app: AppState, show: Title, meta: Meta?, firstFocus: FocusRequester, tv: Boolean) {
    val ctx = LocalContext.current
    var seasons by remember { mutableStateOf<List<Season>?>(null) }
    var sel by remember { mutableIntStateOf(app.lastSeason[show.href] ?: -1) }
    var eps by remember { mutableStateOf<List<Episode>?>(null) }
    var prog by remember { mutableStateOf<Map<String, Prog>>(emptyMap()) }

    LaunchedEffect(show.href) {
        val s = Repo.seasons(show.href)
        seasons = s
        if (sel < 0) {
            // open on the season you watched last
            val last = Repo.lastEpisodeUrl(show.href)
            sel = if (last != null) {
                s.withIndex().filter { last.startsWith(it.value.url) }.maxByOrNull { it.value.url.length }?.index ?: 0
            } else 0
        }
    }
    LaunchedEffect(seasons, sel) {
        val s = seasons?.getOrNull(sel) ?: return@LaunchedEffect
        eps = null
        val list = Repo.episodes(s.url)
        prog = Repo.progressOf(list.map { it.url })
        eps = list
    }
    LaunchedEffect(eps) {
        if (tv && eps != null) runCatching { firstFocus.requestFocus() }
    }
    LaunchedEffect(app.progressTick) {          // VLC just closed: refresh the watched / resume marks
        val l = eps
        if (l != null) prog = Repo.progressOf(l.map { it.url })
    }

    Spacer(Modifier.height(20.dp))
    val ss = seasons
    if (ss == null) {
        Text("Loading seasons…", color = Muted)
        return
    }
    if (ss.isEmpty()) {
        Text("No episodes found, or the server didn't answer.", color = Muted)
        return
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ss.forEachIndexed { i, s -> Chip(s.name, i == sel) { sel = i; app.lastSeason[show.href] = i } }
    }
    Spacer(Modifier.height(12.dp))

    val list = eps
    if (list == null) {
        Text("Loading episodes…", color = Muted)
        return
    }
    if (list.isEmpty()) {
        Text("No video files in this season.", color = Muted)
        return
    }
    val focusIdx = run {
        val partial = list.indexOfFirst { e -> prog[e.url]?.let { !it.watched && it.position > 10_000 } == true }
        if (partial >= 0) partial else list.indexOfFirst { e -> prog[e.url]?.watched != true }.coerceAtLeast(0)
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        list.forEachIndexed { i, ep ->
            val p = prog[ep.url]
            EpisodeRow(
                ep = ep,
                name = meta?.episodeNames?.get("${ep.season}x${ep.num}"),
                p = p,
                modifier = if (i == focusIdx) Modifier.focusRequester(firstFocus) else Modifier,
            ) {
                // play this episode and let the rest of the season follow automatically
                val queue = list.drop(i).map { QItem(it.url, "${show.name} ${it.label}") }
                val pos = if (p != null && !p.watched && p.position > 10_000) p.position else 0L
                app.play(ctx, PlayRequest(queue, 0, pos, show.href))
            }
        }
    }
}

@Composable
fun EpisodeRow(ep: Episode, name: String?, p: Prog?, modifier: Modifier, onClick: () -> Unit) {
    Focusable(onClick = onClick, modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp), scaleOnFocus = 1.01f) {
        Column(Modifier.background(Panel).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(ep.label, color = Accent, fontWeight = FontWeight.Bold, modifier = Modifier.width(76.dp))
                Text(
                    name ?: ep.file.substringBeforeLast('.'),
                    color = TextHi,
                    fontSize = 14.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                val tag = when {
                    p == null -> ""
                    p.watched -> "✓ watched"
                    else -> fmtTime(p.position)
                }
                if (tag.isNotEmpty()) Text(tag, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
            }
            if (p != null && !p.watched && p.duration > 0) {
                LinearProgressIndicator(
                    progress = { (p.position.toFloat() / p.duration).coerceIn(0f, 1f) },
                    color = Accent,
                    trackColor = PanelHi,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
            }
        }
    }
}

// =====================================================================
//  "Play with..." chooser, shown only while the player setting is "Ask"
// =====================================================================
@Composable
fun PlayChoiceDialog(app: AppState, req: PlayRequest) {
    val ctx = LocalContext.current
    var always by remember { mutableStateOf(false) }
    val first = remember { FocusRequester() }

    fun choose(which: String) {
        if (always) app.setPlayer(which)       // remembered: it will never ask again
        app.ask = null
        app.launch(ctx, which, req)
    }

    Dialog(onDismissRequest = { app.ask = null }) {
        LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
        Column(
            Modifier.clip(RoundedCornerShape(16.dp)).background(Panel).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Play with…", color = TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(req.items[req.start].title, color = Muted, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            ActionButton("▶ This app", Modifier.fillMaxWidth().focusRequester(first), primary = true) { choose("app") }
            ActionButton("Open in VLC", Modifier.fillMaxWidth()) { choose("vlc") }
            Chip(if (always) "✓ Always use my choice" else "Always use my choice", always) { always = !always }
        }
    }
}
