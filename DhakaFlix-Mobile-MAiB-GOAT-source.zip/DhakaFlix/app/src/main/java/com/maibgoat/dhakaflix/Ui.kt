package com.maibgoat.dhakaflix

import android.app.Activity
import android.app.UiModeManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.util.Locale

val Bg = Color(0xFF0B0B0D)
val Panel = Color(0xFF17171B)
val PanelHi = Color(0xFF2A2A31)
val Accent = Color(0xFFFF5268)
val Muted = Color(0xFFA6A6AF)
val TextHi = Color(0xFFF2F2F4)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color.White,
            background = Bg,
            surface = Panel,
            onBackground = TextHi,
            onSurface = TextHi,
        ),
        content = content,
    )
}

// ---------------------------------------------------------------------
//  Helpers
// ---------------------------------------------------------------------
fun isTv(ctx: Context): Boolean {
    val ui = ctx.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
    return ui.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
}

fun Context.findActivity(): Activity {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    throw IllegalStateException("No activity")
}

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%d:%02d", m, sec)
}

/** Opens a video in VLC and, when VLC closes, saves where you stopped (if your VLC version reports it). */
object Vlc {
    var launcher: ActivityResultLauncher<Intent>? = null
    private var pendingUrl: String? = null
    private var pendingParent: String = ""

    fun start(ctx: Context, url: String, title: String, posMs: Long, parent: String) {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.parse(url), "video/*")
            .setPackage("org.videolan.vlc")
            .putExtra("title", title)
            .putExtra("position", posMs)
        pendingUrl = url
        pendingParent = parent
        try {
            val l = launcher
            if (l != null) l.launch(i) else ctx.startActivity(i)
        } catch (e: ActivityNotFoundException) {
            pendingUrl = null
            Toast.makeText(ctx, "VLC isn't installed. Get it from the Play Store.", Toast.LENGTH_LONG).show()
        }
    }

    fun onResult(data: Intent?, onSaved: () -> Unit) {
        val url = pendingUrl ?: return
        pendingUrl = null
        if (data == null) return
        val pos = data.getLongExtra("extra_position", -1L)
        val dur = data.getLongExtra("extra_duration", -1L)
        if (pos < 0L || dur <= 0L) return
        val watched = pos > dur * 0.95
        if (!watched && pos < 10_000L) return
        Repo.saveProgress(url, pendingParent, if (watched) 0L else pos, dur, watched, onSaved)
    }
}

// ---------------------------------------------------------------------
//  Focusable: touch = tap, TV remote = D-pad with a white focus ring + zoom
// ---------------------------------------------------------------------
@Composable
fun Focusable(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(10.dp),
    scaleOnFocus: Float = 1.06f,
    content: @Composable BoxScope.() -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    val scale by animateFloatAsState(if (focused) scaleOnFocus else 1f, label = "focusScale")
    Box(
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .then(if (focused) Modifier.border(3.dp, Color.White, shape) else Modifier)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        content = content,
    )
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Focusable(onClick = onClick, shape = RoundedCornerShape(50), scaleOnFocus = 1.05f) {
        Text(
            text,
            color = if (selected) Color.White else Muted,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 14.sp,
            maxLines = 1,
            modifier = Modifier
                .background(if (selected) Accent else Panel)
                .padding(horizontal = 16.dp, vertical = 8.dp),
        )
    }
}

@Composable
fun ActionButton(
    text: String,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Focusable(onClick = { if (enabled) onClick() }, modifier = modifier, shape = RoundedCornerShape(8.dp), scaleOnFocus = 1.04f) {
        Text(
            text,
            color = if (!enabled) Muted else if (primary) Color.White else TextHi,
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp,
            maxLines = 1,
            modifier = Modifier
                .background(if (!enabled) Panel else if (primary) Accent else PanelHi)
                .padding(horizontal = 18.dp, vertical = 10.dp),
        )
    }
}

/** A poster in the grid. Opens the title's folder lazily the first time it is shown, to find its poster image. */
@Composable
fun PosterCard(
    t: Title,
    focusModifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    var poster by remember(t.href) { mutableStateOf(t.poster) }
    var done by remember(t.href) { mutableStateOf(t.resolved) }
    LaunchedEffect(t.href) {
        if (!done) {
            val r = Repo.resolve(t.href)
            if (r != null) {
                poster = r.poster
                done = r.resolved
            }
        }
    }
    Column {
        Focusable(onClick = onClick, modifier = focusModifier.fillMaxWidth().aspectRatio(2f / 3f)) {
            val p = poster
            if (p != null) {
                AsyncImage(
                    model = p,
                    contentDescription = t.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Box(Modifier.fillMaxSize().background(Panel), contentAlignment = Alignment.Center) {
                    Text(
                        if (done) t.name else "…",
                        color = Muted,
                        fontSize = 12.sp,
                        maxLines = 5,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(8.dp),
                    )
                }
            }
            if (t.quality.isNotEmpty()) {
                Text(
                    t.quality,
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp),
                )
            }
            if (t.isSeries) {
                Text(
                    "SERIES",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(4.dp)
                        .background(Accent, RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp),
                )
            }
        }
        Text(
            t.name,
            color = TextHi,
            fontSize = 12.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp),
        )
        if (t.year > 0) Text(t.year.toString(), color = Muted, fontSize = 11.sp)
    }
}
